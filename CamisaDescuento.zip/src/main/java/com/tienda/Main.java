package com.tienda;

public class Main {
    public static void main(String[] args) {
        CamisaVenta venta = new CamisaVenta(50.0, 3); // Ejemplo: 3 camisas a 50 soles cada una
        venta.mostrarResumen();
    }
}
